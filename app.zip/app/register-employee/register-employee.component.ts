import { Component }
from '@angular/core';

@Component({
    selector: ' app-register-employee',
    templateUrl: './register-employee.component.html',
    styleUrls:['register-employee.component.css']
})
export class RegisterEmployeeComponent{

    title:string = "Register Employee Component";
}