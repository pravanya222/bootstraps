import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from "@angular/common/http";
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { DisplayEmployeeComponent } from './display-employee/display-employee.component';
import { RegisterEmployeeComponent } from './register-employee/register-employee.component';
import { DataBindingComponent } from './data-binding/data-binding.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { UnorderedListComponent } from './unordered-list/unordered-list.component';
import { BasicCalculatorComponent } from './basic-calculator/basic-calculator.component';
import { IfComponent } from './if/if.component';
import { SwitchDirectiveComponent } from './switch-directive/switch-directive.component';
import { AttributeDirectiveComponent } from './attribute-directive/attribute-directive.component';

@NgModule({
  declarations: [
    AppComponent,
    DisplayEmployeeComponent,
    RegisterEmployeeComponent,
    DataBindingComponent,
    ParentComponent,
    ChildComponent,
    UnorderedListComponent,
    BasicCalculatorComponent,
    IfComponent,
    SwitchDirectiveComponent,
    AttributeDirectiveComponent
 
  ],
 
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
