import { Component } from '@angular/core';

@Component({
  selector: 'app-switch-directive',
  templateUrl: './switch-directive.component.html',
  styleUrls: ['./switch-directive.component.css']
})
export class SwitchDirectiveComponent {
    num:string;
    items: Item[] = [{countryCode:1, countryName:'USA'},
      {countryCode:2, countryName:'Germany'},
      {countryCode:3, countryName:'UK'},
      {countryCode:4, countryName:'France'},
    ];
    selectedValue1:string ='USA';
}
