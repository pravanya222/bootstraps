export class Student{
    rollNo:number;
    scores:number;
}