import { Component }
from '@angular/core';
import { Employee } from '../model/Employee';

@Component({
    selector: ' app-display-employee',
    templateUrl: './display-employee.component.html',
    styleUrls:['display-employee.component.css']
})
export class DisplayEmployeeComponent{

    title:string = "Display Employee Component";

    employees:Employee[]=[
        {"empId":1001,"empName":'Pravanya',"empSalary":45000,"empDesignation":"Trainer"},
        {"empId":1002,"empName":'Venkatesh',"empSalary":45000,"empDesignation":"Trainee"},
        {"empId":1003,"empName":'Akhila',"empSalary":45000,"empDesignation":"Trainee"},
        {"empId":1004,"empName":'VaraLakshmi',"empSalary":45000,"empDesignation":"Trainer"}
    ]
}