import { Component } from '@angular/core';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent {
      title:string ="Data Binding Example"

      firstName:string = 'pravanya';
      lastName:string ='penumudi';
      isDisabled = true;

      onSave():void{
        console.log("Button Clicked");
      }
}
