import { Component } from '@angular/core';

@Component({
  selector: 'app-unordered-list',
  templateUrl: './unordered-list.component.html',
  styleUrls: ['./unordered-list.component.css']
})
export class UnorderedListComponent {
  items: string[] = ['JavaScript', 'CSS3', 'HTML5', 'Angular'];
}
